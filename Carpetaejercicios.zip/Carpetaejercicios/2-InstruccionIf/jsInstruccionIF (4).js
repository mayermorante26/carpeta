function mostrar()
{
//tomo la edad  

    var edad;

    edad = document.getElementById("edad").value;

    if (edad >= 13 && edad <= 17)
    {
        alert("Es un adolescente");
    }


}//FIN DE LA FUNCIÓN