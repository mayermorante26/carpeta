function mostrar()
{
	//Genero el número RANDOM entre 1 y 10 

    var num;
    num = Math.floor(Math.random() * 10 + 1);
    alert(num);


}//FIN DE LA FUNCIÓN