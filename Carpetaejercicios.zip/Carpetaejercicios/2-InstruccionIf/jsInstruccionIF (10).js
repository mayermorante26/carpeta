function mostrar()
{
	//Genero el número RANDOM entre 1 y 10 

    var nota;
    nota = Math.round(Math.random() * 10);

    if (nota == 9 || nota == 10) {
        alert( nota + " EXCELENTE")
    }
    else
    {
        if (nota > 4)
        {
            alert(nota + " APROBO")
        }
        else
        {
            alert( nota + " Vamos, la proxima se puede")
        }
    }

}//FIN DE LA FUNCIÓN