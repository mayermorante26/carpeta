function mostrar() {
    //tomo la edad  

    var edad;

    edad = document.getElementById("edad").value;

    if (edad < 13) {
        alert(" Es un niño");
    }
    else {
        if ((edad < 18)) {
            alert(" Es adolescente");
        }
        else {
            alert(" Es Mayor");
        }
    }
}
//FIN DE LA FUNCIÓN